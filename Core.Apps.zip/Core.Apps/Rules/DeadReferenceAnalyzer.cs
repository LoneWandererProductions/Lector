﻿/*
 * COPYRIGHT:   See COPYING in the top level directory
 * PROJECT:     Core.Apps.Rules
 * FILE:        DeadReferenceAnalyzer.cs
 * PURPOSE:     Checks code for unused project/assembly references.
 * PROGRAMMER:  Peter Geinitz (Wayfarer)
 */

using Core.Apps.Enums;
using Core.Apps.Helper;
using Core.Apps.Interface;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Weaver;
using Weaver.Interfaces;
using Weaver.Messages;

namespace Core.Apps.Rules
{
    /// <inheritdoc cref="ICodeAnalyzer" />
    /// <summary>
    /// Command that detects unused project/assembly references.
    /// </summary>
    /// <seealso cref="ICommand" />
    public sealed class DeadReferenceAnalyzer : ICommand, ICodeAnalyzer
    {
        /// <inheritdoc cref="ICodeAnalyzer" />
        public string Namespace => "Analyzer";

        /// <inheritdoc cref="ICodeAnalyzer" />
        public string Name => "deadrefs";

        /// <inheritdoc cref="ICodeAnalyzer" />
        public string Description => "Detects unused project/assembly references.";

        /// <inheritdoc />
        public int ParameterCount => 1;

        /// <inheritdoc />
        public IReadOnlyDictionary<string, int>? Extensions => null;

        /// <inheritdoc />
        public CommandSignature Signature => new(Namespace, Name, ParameterCount);

        /// <inheritdoc />
        public IEnumerable<Diagnostic> Analyze(string? filePath, string fileContent)
        {
            if (string.IsNullOrEmpty(filePath) ||
                !Path.GetExtension(filePath).Equals(".csproj", StringComparison.OrdinalIgnoreCase))
                yield break;

            // FileContent is empty for .csproj execution → load file if needed
            var xml = !string.IsNullOrEmpty(fileContent) ? fileContent : File.ReadAllText(filePath);
            var project = new ProjectReferenceInfo(xml);

            var unused = project.GetUnusedReferences();
            foreach (var r in unused)
            {
                yield return new Diagnostic(
                    Name,
                    DiagnosticSeverity.Warning,
                    filePath,
                    0,
                    $"Unused reference '{r}' detected.",
                    DiagnosticImpact.Other
                );
            }
        }

        /// <inheritdoc />
        public CommandResult Execute(params string?[] args)
        {
            List<Diagnostic> results;
            try
            {
                results = AnalyzerExecutor.ExecutePath(this, args, "Usage: deadrefs <folderOrFile (.csproj)>");
            }
            catch (Exception ex)
            {
                return CommandResult.Fail(ex.Message);
            }

            var output = string.Join("\n", results.Select(d => $"{Path.GetFileName(d.FilePath)} -> {d.Message}"));
            return CommandResult.Ok(
                output.Length > 0 ? $"Unused references detected:\n{output}" : "No unused references detected.",
                EnumTypes.Wstring);
        }
    }
}
