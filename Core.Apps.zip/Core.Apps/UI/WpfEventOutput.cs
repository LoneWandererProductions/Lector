﻿/*
 * COPYRIGHT:   See COPYING in the top level directory
 * PROJECT:     Core.Apps.UI
 * FILE:        WpfEventOutput.cs
 * PURPOSE:     Sample wpf side channel for event output.
 * PROGRAMMER:  Peter Geinitz (Wayfarer)
 */

using System.Threading;
using Core.Apps.Interface;

namespace Core.Apps.UI
{
    /// <inheritdoc />
    /// <summary>
    /// Logging output that displays messages in a WPF window.
    /// </summary>
    /// <seealso cref="IEventOutput" />
    public sealed class WpfEventOutput : IEventOutput
    {
        /// <summary>
        /// The window
        /// </summary>
        private LogWindow? _window;

        /// <summary>
        /// The lock
        /// </summary>
        private readonly Lock _lock = new();

        /// <summary>
        /// Initializes a new instance of the <see cref="WpfEventOutput"/> class.
        /// </summary>
        public WpfEventOutput()
        {
        }

        /// <summary>
        /// Writes the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        public void Write(string message)
        {
            EnsureWindow();
            _window!.Dispatcher.BeginInvoke(() => _window.Append(message));
        }

        /// <summary>
        /// Ensures the window.
        /// Needed in console Context.
        /// </summary>
        private void EnsureWindow()
        {
            if (_window != null) return;

            lock (_lock)
            {
                if (_window != null) return;

                var tcs = new System.Threading.Tasks.TaskCompletionSource<LogWindow>();

                var thread = new Thread(() =>
                {
                    var w = new LogWindow();

                    // Clean up the thread and the reference when the user closes the window
                    w.Closed += (s, e) =>
                    {
                        lock (_lock)
                        {
                            _window = null;
                        }

                        // Shut down the dispatcher so the background thread can exit properly
                        System.Windows.Threading.Dispatcher.ExitAllFrames();
                    };

                    w.Show();
                    _window = w;
                    tcs.SetResult(w);
                    System.Windows.Threading.Dispatcher.Run();
                });

                thread.SetApartmentState(ApartmentState.STA);
                thread.IsBackground = true;
                thread.Start();

                _window = tcs.Task.Result;
            }
        }
    }
}
